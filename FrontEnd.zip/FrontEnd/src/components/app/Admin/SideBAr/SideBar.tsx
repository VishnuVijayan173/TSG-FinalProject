import React from 'react';
import {
  CDBSidebar,
  CDBSidebarContent,
  CDBSidebarHeader,
  CDBSidebarMenu,
  CDBSidebarMenuItem,
} from 'cdbreact';
import { Navigate, NavLink} from 'react-router-dom';
import {Navbar, Button, Nav, Container,Form} from 'react-bootstrap';
// import logo from '../static/logo.png';
import './SideBar.css';
import {useNavigate} from 'react-router-dom';



const AdminSideBar = (props:any) => (
    <div>
        <div className='sidebar'>
            <CDBSidebar textColor=''
                backgroundColor=""
                className={''}
                breakpoint={0}
                toggled={false}
                minWidth={''}
                maxWidth={''}>
                <CDBSidebarHeader prefix={<i className="fa fa-bars" />}>
                    Navigation
                </CDBSidebarHeader>
                <CDBSidebarContent>
                    <CDBSidebarMenu>
                        <NavLink exact to='/dashboard' activateClassName="activeClicked" {...props}>
                            <CDBSidebarMenuItem icon="home">Home</CDBSidebarMenuItem>
                        </NavLink>
                        <NavLink exact to="dashboard/bugs" activeClassName="activeClicked" {...props}>
                            <CDBSidebarMenuItem icon="list">User List</CDBSidebarMenuItem>
                        </NavLink>
                        <NavLink exact to="/dashboard/manage" activeClassName="activeClicked"{...props }>
                            <CDBSidebarMenuItem icon="user">Manage User</CDBSidebarMenuItem>
                        </NavLink>
                        <NavLink exact to="/dashboard/manage" activeClassName="activeClicked"{...props }>
                            <CDBSidebarMenuItem icon="user">Bug List</CDBSidebarMenuItem>
                        </NavLink>
                        <NavLink exact to="/dashboard/manage" activeClassName="activeClicked"{...props }>
                            <CDBSidebarMenuItem icon="user">Manage Bug</CDBSidebarMenuItem>
                        </NavLink>
                    </CDBSidebarMenu>
                </CDBSidebarContent>
            </CDBSidebar>
        </div>
    </div>
);

export default AdminSideBar;