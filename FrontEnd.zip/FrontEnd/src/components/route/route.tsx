import React from 'react';
import { Route, Routes } from 'react-router-dom';
import BugList from '../../pages/User/BugsList/BugsList';
import Dashboard from '../../pages/User/Dashboard/Dashboard';
import Home from '../../pages/User/Home/Home';
import Login from '../../pages/User/Login/Login';
import ManageBugs from '../../pages/User/ManageBugs/ManageBugs';
import UserList from '../../pages/Admin/UserList/UserList';
import AdminBugList from '../../pages/Admin/BugsList/BugsList';
//import ManageUsers from '../../pages/Admin/ManageUsers/ManageUsers';
const AppRoutes = () => {
    return (
        <Routes>
            <Route path='/' element={<Login/>} />
            <Route path="/dashboard" element={<Dashboard/>} >
              <Route index element= {<Home/>}/>
              <Route path='bugs' element= {<BugList/>}/>
              <Route path='manage' element= {<ManageBugs/>}/>
              <Route path='user' element= {<UserList/>}/>
              <Route path='bugList' element= {<AdminBugList/>}/>

            </Route>
        </Routes>
    );
};

export default AppRoutes;
