import { AnyAction, Dispatch } from 'redux';
import { LOGIN } from './types';
import { handleError } from '../../utils/handle-error';
import axios from 'axios';

export const loginApi = (data:any) => async (dispatch: Dispatch<AnyAction>) => {
    try {
        // eslint-disable-next-line no-console
        console.log(data);
        const response = await axios.post('https://localhost:44368/User/login', {
        userName : data.userName,
        password : data.password,
    });
    // eslint-disable-next-line no-console
    console.log('payload',response.data.result);
        dispatch({
            type: LOGIN,
            payload: response.data,
        });
        // eslint-disable-next-line no-console
        console.log(response.data.result);
        localStorage.setItem('token',response.data.result);
        return response.data.result;
    }
     catch (err: any) {
        handleError(err);
    }
};