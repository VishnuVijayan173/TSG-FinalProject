export const UPDATE_COUNT = 'UPDATE_COUNT';
export const API_CALL = 'API_CALL';
export const LOGIN = 'LOGIN';
