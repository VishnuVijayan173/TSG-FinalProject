import React from 'react';
import { useSelector } from 'react-redux';
import { Link } from 'react-router-dom';
import { AppState } from '../../../redux/store';
import { Card, CardImg } from 'reactstrap';
import './Home.css';
const Home = () => {
    return (
        <>
        <div style={{margin:200}} className="d-flex justify-content-center ">
            <Card className="cardImage shake-lr">
            <h1 >BUG TRACKER</h1>
            <CardImg className="" src="https://cdn3.iconfinder.com/data/icons/spring-2-1/30/Ladybug-256.png"
             alt="Bug logo" />
            </Card>
          </div>
        </>
    );
};
export default Home;
