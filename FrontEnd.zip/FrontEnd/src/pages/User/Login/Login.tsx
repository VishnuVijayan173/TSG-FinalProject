import React, { useState } from 'react';
import { useSelector } from 'react-redux';
import { Link, Navigate } from 'react-router-dom';
import { text } from 'stream/consumers';
import Input from '../../../components/app/input/input';
import { loginApi } from '../../../redux/actions/authentication';
import { AppState, useAppThunkDispatch } from '../../../redux/store';
import './Login.css';

const Login = () => {
    const [userName, setUserName]= useState('');
    const [password, setPassword]= useState('');
    const dispatch = useAppThunkDispatch();

    const User = useSelector((state: AppState) => state.login);
  // eslint-disable-next-line no-console
  console.log('User ',User);
  const Handleclick =(e:any)=>{
     e.preventDefault();
    dispatch(loginApi({
      userName,password
    }));

    window.location.href='http://localhost:3000/dashboard';
  };




    return(

      <div className='maincontainer'>
        <div className='container-fluid'>
            <div className='row no-gutter'>
                <div className='col-md-6 d-none d-md-flex bg-image'></div>
                <div className='col-md-6 bg-light'>
                    <div className='login d-flex align-items-center py-5'>
                        <div className='container LoginComponents'>
                            <div className='row LoginCard'>
                                <div className='col-lg-10 col-xl-7 mx-auto'>
                                    <h3 className='display-4'>LOGIN</h3>
                                    <form>
                                    <div className="form-group mt-3">
                                      <label>UserName</label>
                                      <input
                                        type="text"
                                        className="form-control mt-1"
                                        placeholder="Enter username"
                                        onChange={(e) => {
                                          setUserName(e.target.value);
                                        }}
                                      />
                                    </div>
                                    <div className="form-group mt-3">
                                      <label>Password</label>
                                      <input
                                        type="password"
                                        className="form-control mt-1"
                                        placeholder="Enter password"
                                        onChange={(e) => {
                                          setPassword(e.target.value);
                                        }}
                                      />
                                    </div>
                                        <div className='d-grid gap-2 mt-2'>
                                        <button type='submit' onClick={Handleclick}
                                         className='btn btn-primary btn-block text-uppercase
                                         mb-2 rounded-pill shadow-sm'>
                                          Sign in</button>
                                        </div>

                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
      </div>
    );
            };
export default Login;


