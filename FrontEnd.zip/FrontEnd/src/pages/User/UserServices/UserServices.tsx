import axios from '../../../utils/interceptors';



export function getBugs(){
    return axios.get('https://localhost:44368/Bug')
    .then((response:any) => response.data)
    // eslint-disable-next-line no-console
    .catch((err:any) => console.log('Error: ', err));
}
export function addBug(bug:any){
    return axios.post('https://localhost:44368/Bug' , {
        BugName:bug[0].value,
        BugDesciption:bug[1].value,
        StatusID:bug[2].value,
        ProjectAllocation:bug[3].value
        })
    .then((response:any) => response.data)
    // eslint-disable-next-line no-console
    .catch((err:any) => console.log('Error: ', err));
}