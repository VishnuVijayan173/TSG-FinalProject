import React, { useEffect, useState } from 'react';
import { Table, ButtonToolbar } from 'react-bootstrap';
//import AddBugModal from './AddBugModal';
import axios from 'axios';
//import { GetBugs } from '../services/BugServices';
import { FaEdit } from 'react-icons/fa';
import { RiDeleteBin5Line } from 'react-icons/ri';
import Button from 'react-bootstrap/Button';
import Modal from 'react-bootstrap/Modal';
import { toast, ToastContainer } from 'react-toastify';
import Form from 'react-bootstrap/Form';
import { addBug, getBugs } from '../UserServices/UserServices';



const ManageBugs = (props: any) => {
    const [show, setShow] = useState(false);

  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);

  const [bugs, setBugs] = useState([]);
  const [addModalShow, setAddModalShow] = useState(false);
  const [isUpdated, setIsUpdated] = useState(false);


  const [editBugId, setEditBugId] = useState();
  const [editBugName, setEditBugName] = useState('');
  const [editBugDescription, setEditBugDescription] = useState('');
  const [editBugStatus, setEditBugStatus] = useState('');
  const [editProject, setEditProject] = useState('');
  const [editRaisedBy, setEditRaisedBy] = useState('');

  let mounted = true;
  useEffect(() => {

    if (bugs.length && !isUpdated) {
        return;
    }
    GetBugs();
    return () => {
        mounted = false;
        setIsUpdated(false);
    };
}, [isUpdated, bugs]);

function GetBugs() {
    getBugs().then((data:any) => {
        if (mounted) {
            setBugs(data);
        }
    });
}

const handleSubmit = (e: any) => {

    e.preventDefault();


    addBug(e.target).then(
        (result:any) => {
            toast.success(result.message, {
                position: 'top-center',
                autoClose: 5001,
                hideProgressBar: false,
                closeOnClick: true,
                pauseOnHover: true,
                draggable: true,
                progress: 1,
                theme: 'dark',
            });
            setTimeout(() => {
                window.location.href = 'http://localhost:3000/manage';
            }, 800);
            // Set the updated flag in parent component
            props.setUpdated(true);
        },
        // If failed, show error message
        () => {
            toast.error('Failed to add movie', {
                position: 'top-center',
                autoClose: 5001,
                hideProgressBar: false,
                closeOnClick: true,
                pauseOnHover: true,
                draggable: true,
                progress: 1,
                theme: 'dark',
            });
        }
    );
};

  return (
    <div className="container-fluid side-container">
      <ToastContainer />
      <div className="row side-row">
        <p id="manage"></p>
        <Table striped bordered hover className="react-bootstrap-table" id="dataTable">
          <thead>
            <tr>
              <th >BugID</th>
              <th>Bug Name</th>
              <th>Bug Description</th>
              <th>Bug Satus</th>
              <th>Project</th>
              <th>Raised By</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
          {bugs.map((bug:any) =>
              <tr key={bug.bugID}>
                <td>{bug.bugID}</td>
                <td>{bug.bugName}</td>
                <td>{bug.bugDescription}</td>
                <td>{bug.bugStatusID}</td>
                <td>{bug.projectID}</td>
                <td>{bug.raisedBy}</td>
                <td>
                  <Button className="mr-2" variant="danger"
                    >
                    <RiDeleteBin5Line />
                  </Button>
                  <span>&nbsp;&nbsp;&nbsp;</span>
                  <Button className="mr-2"
                     >
                    <FaEdit />
                  </Button>

                </td>
              </tr>
            )}
          </tbody>

        </Table>
        <ButtonToolbar>
          <Button variant="primary" onClick={handleShow} >
            Add Bug
          </Button>
        </ButtonToolbar>
        <Modal show={show} onHide={handleClose}>
        <Modal.Header closeButton>
          <Modal.Title>Add Bug Details</Modal.Title>
        </Modal.Header>
        <Modal.Body>
            <Form>
            <div className="container">
              <div>
                <label>Bug Name</label>
                <input type="text" className="form-control" placeholder="Enter BugName"
                  value={editBugName} onChange={(e) => setEditBugName(e.target.value)}
                />
              </div>
              <div>
                <label>Bug Description</label>
                <input type="text" className="form-control" placeholder="Enter description"
                  value={editBugDescription} onChange={(e) => setEditBugDescription(e.target.value)}
                />
              </div>
              <div>
                <label>Bug Status</label>
                <input type="text" className="form-control" placeholder="Enter Status"
                  value={editBugStatus} onChange={(e) => setEditBugStatus(e.target.value)}
                />
              </div>
              <div>
                <label>Project</label>
                <input type="text" className="form-control" placeholder="Enter Project"
                  value={editProject} onChange={(e) => setEditProject(e.target.value)}
                />
              </div>
              <div>
                <label>Raised By</label>
                <input type="text" className="form-control" placeholder="Raised By"
                  value={editRaisedBy} onChange={(e) => setEditRaisedBy(e.target.value)}
                />
              </div>
            </div>
            </Form>
          </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={handleClose}>
            Close
          </Button>
          <Button variant="primary" onClick={handleClose}>
            Save Changes
          </Button>
        </Modal.Footer>
      </Modal>
      </div>
    </div>
  );
};

export default ManageBugs;