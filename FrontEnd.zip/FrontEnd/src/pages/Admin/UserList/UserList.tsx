import React, { useEffect, useState } from 'react';
import { Button, ButtonToolbar, Form, Modal, Table } from 'react-bootstrap';
import { getUsers, getRoles, addUser } from '../AdminServices';
import axios from 'axios';
import { toast } from 'react-toastify';

const UserList = (props:any) => {
  const [users, setUsers] = useState([]);
  const [isUpdated, setIsupdated] = useState(false);

  const [show, setShow] = useState(false);
  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);

  const [userName, setUserName] = useState('');
  const [emailAddress, setEmailAddress] = useState('');
  const [password, setPassword] = useState('');
  const [roleId, setRoleId] = useState('');
  const [updatedBy, setUpdatedBy] = useState('');
  const [roles, setRoles] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const [message, setMessage] = useState('');

  let mounted = true;
    useEffect(() => {
        if (users.length && !isUpdated) {
            return;
        }

        GetUsers();

        return () => {
            mounted = false;
            setIsupdated(false);
        };
    }, [isUpdated, users]);

    function GetUsers() {
      getUsers().then((data:any) => {
          if (mounted) {
              setUsers(data);
          }

          // eslint-disable-next-line no-console
          console.log(data);
      });
    }
      useEffect(() => {
        getRoles().then((data:any) => {
          setRoles(data);
        });
      }, []);


  const handleSubmit = (e: any) => {
    // Prevent default form submit behavior
    e.preventDefault();

    // Call addMovie function to add the movie data to the API
    addUser(e.target).then(
        // If success, show success message and redirect to manage page
        (result:any) => {
            toast.success(result.message, {
                position: 'top-center',
                autoClose: 5001,
                hideProgressBar: false,
                closeOnClick: true,
                pauseOnHover: true,
                draggable: true,
                progress: 1,
                theme: 'dark',
            });
            setTimeout(() => {
                window.location.href = 'http://localhost:3000/manage';
            }, 800);
            // Set the updated flag in parent component
            props.setUpdated(true);
        },
        // If failed, show error message
        () => {
            toast.error('Failed to add movie', {
                position: 'top-center',
                autoClose: 5001,
                hideProgressBar: false,
                closeOnClick: true,
                pauseOnHover: true,
                draggable: true,
                progress: 1,
                theme: 'dark',
            });
        }
    );
};

  return (
    <>
      <div className="container-fluid side-container">
        <div className="row ">
          <span>
            <input
              type="text"
              placeholder="Search..."
              onChange={e => (e.target.value)}
            />
            <button>Search</button>
          </span>
        </div>
        <div className="row " >
          <p id="before-table"></p>
          <Table striped bordered hover className="react-bootstrap-table" id="dataTable">
            <thead>
              <tr>
                <th>UserID</th>
                <th>UserName</th>
                <th>Email</th>
              </tr>
            </thead>
            <tbody>
              {users.map((user:any) =>
                <tr key={user.userID}>
                  <td>{user.userID}</td>
                  <td>{user.userName}</td>
                  <td>{user.emailAddress}</td>
                  <td></td>
                </tr>
              )}
            </tbody>
          </Table>
          <ButtonToolbar>
            <Button variant="primary" onClick={handleShow}>
              Add User
            </Button>
          </ButtonToolbar>
          <Modal show={show} onHide={handleClose}>
            <Modal.Header closeButton>
              <Modal.Title>Add User Details</Modal.Title>
            </Modal.Header>
            <Modal.Body>
              <Form onSubmit={handleSubmit}>
                <div>
                  <label htmlFor="userName">Username:</label>
        <input type="text" id="userName" value={userName} onChange={(event) => setUserName(event.target.value)} />
      </div>
      <div>
        <label htmlFor="emailAddress">Email Address:</label>
        <input type="email" id="emailAddress" value={emailAddress}
         onChange={(event) => setEmailAddress(event.target.value)} />
      </div>
      <div>
        <label htmlFor="password">Password:</label>
        <input type="password" id="password" value={password} onChange={(event) => setPassword(event.target.value)} />
      </div>
      <div>
        <label htmlFor="roleId">Role:</label>
        <select id="roleId" value={roleId} onChange={(event) => setRoleId(event.target.value)}>
          <option value="">Select a role</option>
          {roles.map((role:any) => (
            <option key={role.roleID} value={role.roleID}>
              {role.roleName}
            </option>
          ))}
        </select>
      </div>
      <input type="hidden" id="updatedBy" value={updatedBy} />
      {message && <div>{message}</div>}
            </Form>
          </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={handleClose}>
            Close
          </Button>
          <Button variant="primary" type='submit' onClick={handleClose}>
            Save Changes
          </Button>
        </Modal.Footer>
      </Modal>
       </div>
     </div>
        </>
    );
};
export default UserList;
