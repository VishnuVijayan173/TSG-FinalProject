import React, { useEffect, useState } from 'react';
import { Table } from 'react-bootstrap';
import { getBugs } from '../../User/UserServices/UserServices';


const AdminBugList = () => {
  const [bugs, setBugs] = useState([]);
  const [isUpdated, setIsupdated] = useState(false);


  let mounted = true;
    useEffect(() => {
        if (bugs.length && !isUpdated) {
            return;
        }

        GetBugs();

        return () => {
            mounted = false;
            setIsupdated(false);
        };
    }, [isUpdated, bugs]);

    function GetBugs() {
      getBugs().then((data:any) => {
          if (mounted) {
              setBugs(data);
          }

          // eslint-disable-next-line no-console
          console.log(data);
      });
  }

    return (
        <>
      <div className="container-fluid side-container">
      <div className="row ">
        <span>
      <input
        type="text"
        placeholder="Search..."
        onChange={e => (e.target.value)}
      />
      <button >Search</button>
      </span>
    </div>
      <div className="row " >
       <p id="before-table"></p>
           <Table striped bordered hover className="react-bootstrap-table" id="dataTable">
           <thead>
               <tr>
               <th>BugID</th>
               <th>Bug Name</th>
               <th>Bug Description</th>
               <th>Bug Status</th>
               <th>Project</th>
               <th>Raised By</th>
               </tr>
           </thead>
           <tbody>
           {bugs.map((bug:any) =>
                <tr key={bug.bugID}>
                  <td>{bug.bugID}</td>
                  <td>{bug.bugName}</td>
                  <td>{bug.bugDescription}</td>
                  <td>{bug.statusID}</td>
                  <td>if{bug.allocationID}_</td>
                  <td>{bug.raisedBy}</td>
                  <td>
                  </td>
              </tr>
             )}
           </tbody>
       </Table>
       </div>
     </div>
        </>
    );
};
export default AdminBugList;
