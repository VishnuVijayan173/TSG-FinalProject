﻿using BugProject.Application.Common.Interfaces;
using BugProject.Application.Services;
using BugProject.Domain.Entities;
using BugProject.Domain.Repositories;
using BugProject.Infrastructure.Persistence.Repository;
using Moq;
using Xunit;

namespace BugProject.Tests
{
    public class TestBugServices
    {
        private readonly IBugRepository _bugRepositoryMock;
        private readonly BugService _bugService; public TestBugServices()
        {
            _bugRepositoryMock = Mock.Of<IBugRepository>();
            _bugService = new BugService(_bugRepositoryMock);
        }
        [Fact]
        public async Task AddAsync_AddsBug()
        {
            // Arrange
            var bug = new Bug { BugName = "TestBug" };
            Mock.Get(_bugRepositoryMock)
            .Setup(repo => repo.AddAsync(bug))
            .ReturnsAsync(bug);             // Act
            var result = await _bugService.AddAsync(bug);             // Assert
            Assert.Equal(bug, result);
        }
        [Fact]
        public async Task DeleteAsync_DeletesBug()
        {
            // Arrange
            var bugId = Guid.NewGuid();
            var bug = new Bug { BugID = bugId, BugName = "Bug 1", BugDescription = "Description 1" };
            Mock.Get(_bugRepositoryMock)
            .Setup(x => x.DeleteAsync(bugId)).ReturnsAsync(bug);

            // Act
            var result = await _bugService.DeleteAsync(bugId);

            // Assert
            Assert.Equal(bug, result);
        }
        [Fact]
        public async Task GetAllAsync_ReturnsAllCities()
        {
            // Arrange
            var bugs = new List<Bug>
            {
                new Bug { BugID = Guid.NewGuid(), BugName = "Bug 1", BugDescription = "Description 1" },
                new Bug { BugID = Guid.NewGuid(), BugName = "Bug 2", BugDescription = "Description 2" },
                new Bug { BugID = Guid.NewGuid(), BugName = "Bug 3", BugDescription = "Description 3" }
            };
            Mock.Get(_bugRepositoryMock)
            .Setup(x => x.GetAllAsync()).ReturnsAsync(bugs);

            // Act
            var result = await _bugService.GetAllAsync();

            // Assert
            Assert.Equal(bugs, result);
        }
        [Fact]
        public async Task GetAsync_ReturnsBug()
        {
            // Arrange
            var bugId = Guid.NewGuid();
            var bug = new Bug { BugID = bugId, BugName = "Bug 1", BugDescription = "Description 1" };

            Mock.Get(_bugRepositoryMock)
                .Setup(x => x.GetAsync(bugId)).ReturnsAsync(bug);

            // Act
            var result = await _bugService.GetAsync(bugId);

            // Assert
            Assert.Equal(bug, result);
        }
        [Fact]
        public async Task UpdateAsync_UpdatesBug()
        {
            // Arrange
            var bugId = Guid.NewGuid();
            var bug = new Bug { BugID = bugId, BugName = "Bug 1", BugDescription = "Description 1" };
            var updatedBug = new Bug { BugName = "UpdatedBug" };
            Mock.Get(_bugRepositoryMock)
            .Setup(x => x.UpdateAsync(bugId, updatedBug))
            .ReturnsAsync(updatedBug);            
            var result = await _bugService.UpdateAsync(bugId, updatedBug);             
            Assert.Equal(updatedBug, result);


            
        }
    }
}