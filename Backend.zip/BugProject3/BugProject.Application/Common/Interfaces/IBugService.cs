﻿using BugProject.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BugProject.Application.Common.Interfaces
{
    public interface IBugService
    {
        Task<IEnumerable<Bug>> GetAllAsync();

        Task<Bug> GetAsync(Guid id);

        Task<Bug> AddAsync(Bug bug);

        Task<Bug> DeleteAsync(Guid id);

        Task<Bug> UpdateAsync(Guid id, Bug bug);

    }
}
