﻿using BugProject.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BugProject.Application.Common.Interfaces
{
    public interface IUserService
    {
        Task<IEnumerable<User>> GetAllAsync();

        Task<User> GetAsync(Guid id);

        Task<User> AddAsync(User user);

        Task<User> DeleteAsync(Guid id);

        Task<User> UpdateAsync(Guid id, User user);
        Task<User> AuthenticateAsync(string userName, string password);
        Task<User> RegisterAsync(string username, string email, string password, Guid RoleId, Guid updatedBy);
        Task<User> FindByNameAsync(string username);
    }
}
