﻿using BugProject.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BugProject.Application.Common.Interfaces
{
    public interface IProjectAllocationService
    {
        Task<IEnumerable<ProjectAllocation>> GetAllAsync();

        Task<ProjectAllocation> GetAsync(Guid id);

        Task<ProjectAllocation> AddAsync(ProjectAllocation projectAllocation);

        Task<ProjectAllocation> DeleteAsync(Guid id);

        Task<ProjectAllocation> UpdateAsync(Guid id, ProjectAllocation projectAllocation);
    }
}
