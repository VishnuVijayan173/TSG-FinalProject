﻿using BugProject.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BugProject.Application.Common.Interfaces
{
    public interface IUser_RoleService
    {
        Task<IEnumerable<User_Role>> GetAllAsync();

        Task<User_Role> GetAsync(Guid id);

        Task<User_Role> AddAsync(User_Role user_Role);

        Task<User_Role> DeleteAsync(Guid id);

        Task<User_Role> UpdateAsync(Guid id, User_Role user_Role);

    }
}
