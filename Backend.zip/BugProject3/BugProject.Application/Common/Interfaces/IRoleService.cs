﻿using BugProject.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BugProject.Application.Common.Interfaces
{
    public interface IRoleService
    {
        Task<IEnumerable<Role>> GetAllAsync();

        Task<Role> GetAsync(Guid id);

        Task<Role> AddAsync(Role role);

        Task<Role> DeleteAsync(Guid id);

        Task<Role> UpdateAsync(Guid id, Role role);
    }
}
