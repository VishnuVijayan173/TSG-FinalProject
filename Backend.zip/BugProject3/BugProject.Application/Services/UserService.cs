﻿using Azure.Identity;
using BugProject.Application.Common.Interfaces;
using BugProject.Domain.Entities;
using BugProject.Domain.Repositories;
using BugProject.Infrastructure.Persistence.DTO;
using BugProject.Infrastructure.UnitOfWork;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BugProject.Application.Services
{
    public class UserService : IUserService
    {
        private readonly IUserRepository userRepository;
      
        public UserService(IUserRepository userRepository)
        {
            this.userRepository = userRepository;
        }
        public async Task<IEnumerable<Domain.Entities.User>> GetAllAsync()
        {
            return await userRepository.GetAllAsync();
        }
        public async Task<Domain.Entities.User> GetAsync(Guid id)
        {
            return await userRepository.GetAsync(id);
        }
        public async Task<Domain.Entities.User> AddAsync(Domain.Entities.User user)
        {
            return await userRepository.AddAsync(user);
        }
        public async Task<Domain.Entities.User> DeleteAsync(Guid id)
        {
            return await userRepository.DeleteAsync(id);
        }
        public async Task<Domain.Entities.User> UpdateAsync(Guid id, Domain.Entities.User user)
        {
            return await userRepository.UpdateAsync(id, user);
        }


        public async Task<Domain.Entities.User> AuthenticateAsync(string userName, string password)
        {
            return await userRepository.AuthenticateAsync(userName, password);
        }
        public async Task<Domain.Entities.User> RegisterAsync(string username, string email, string password, Guid RoleId, Guid updatedBy)
        {
            return await userRepository.RegisterAsync(username,email,password,RoleId,updatedBy);
        }
        public async Task<Domain.Entities.User> FindByNameAsync(string username)
        {
            return await userRepository.FindByNameAsync(username);
        }

        
    }
}
