﻿using BugProject.Application.Common.Interfaces;
using BugProject.Domain.Entities;
using BugProject.Domain.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BugProject.Application.Services
{
    public class User_RoleService : IUser_RoleService
    {


        private readonly IUser_RoleRepository user_RoleRepository;
        public User_RoleService(IUser_RoleRepository user_RoleRepository)
        {
            this.user_RoleRepository = user_RoleRepository;


        }
        public async Task<IEnumerable<Domain.Entities.User_Role>> GetAllAsync()
        {

            return await user_RoleRepository.GetAllAsync();
        }
        public async Task<Domain.Entities.User_Role> GetAsync(Guid id)
        {
            return await user_RoleRepository.GetAsync(id);
        }
        public async Task<Domain.Entities.User_Role> AddAsync(Domain.Entities.User_Role user_Role)
        {

            return await user_RoleRepository.AddAsync(user_Role);

        }
        public async Task<Domain.Entities.User_Role> DeleteAsync(Guid id)
        {
            return await user_RoleRepository.DeleteAsync(id);
        }
        public async Task<Domain.Entities.User_Role> UpdateAsync(Guid id, Domain.Entities.User_Role user_Role)
        {
            return await user_RoleRepository.UpdateAsync(id, user_Role);
        }
    }
}
