﻿using BugProject.Application.Common.Interfaces;
using BugProject.Domain.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BugProject.Application.Services
{
    public class StatusService : IStatusService
    {
        private readonly IStatusRepository statusRepository;
        public StatusService(IStatusRepository statusRepository)
        {
            this.statusRepository = statusRepository;
        }
        public async Task<IEnumerable<Domain.Entities.Status>> GetAllAsync()
        {
            return await statusRepository.GetAllAsync();
        }
        public async Task<Domain.Entities.Status> GetAsync(Guid id)
        {
            return await statusRepository.GetAsync(id);
        }
        public async Task<Domain.Entities.Status> AddAsync(Domain.Entities.Status status)
        {
            return await statusRepository.AddAsync(status);
        }
        public async Task<Domain.Entities.Status> DeleteAsync(Guid id)
        {
            return await statusRepository.DeleteAsync(id);
        }
        public async Task<Domain.Entities.Status> UpdateAsync(Guid id, Domain.Entities.Status status)
        {
            return await statusRepository.UpdateAsync(id, status);
        }

    }
}
