﻿using BugProject.Application.Common.Interfaces;
using BugProject.Domain.Entities;
using BugProject.Domain.Repositories;
using BugProject.Infrastructure.Persistence.Data;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BugProject.Infrastructure.Persistence.Repository
{
    public class ProjectAllocationRepository : Repository<ProjectAllocation>, IProjectAllocationRepository
    {
        public ProjectAllocationRepository(IUnitOfWork unitOfWork) : base(unitOfWork)
        {
        }
    }
}
