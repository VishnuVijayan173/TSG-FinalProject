﻿using BugProject.Application.Common.Interfaces;
using BugProject.Domain.Entities;
using BugProject.Domain.Repositories;
using BugProject.Infrastructure.Persistence.Data;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BugProject.Infrastructure.Persistence.Repository
{
    public class UserRepository : Repository<User>, IUserRepository
    {
        private readonly IUnitOfWork _unitOfWork;
        public UserRepository(IUnitOfWork unitOfWork) : base(unitOfWork)
        {
            this._unitOfWork= unitOfWork;
            
        }
        public async Task<User> AuthenticateAsync(string username, string password)
        {
            var user = await _unitOfWork.Context.Users
        .Include(x => x.role)
        .SingleOrDefaultAsync(x => x.UserName == username);

            if (user == null)
            {
                return null;
            }

            // Check if the provided password matches the hashed password in the database
            if (BCrypt.Net.BCrypt.Verify(password, user.Password))
            {
                return user;
            }

            return null;
        }
        public async Task<User> FindByNameAsync(string username)
        {
            return await _unitOfWork.Context.Users
     .FirstOrDefaultAsync(u => u.UserName == username);
        }




        public async Task<User> RegisterAsync(string username, string email, string password, Guid RoleId,Guid updatedBy)
        {
            string hashedPassword = BCrypt.Net.BCrypt.HashPassword(password);

            var user = new User
            {
                UserName = username,
                EmailAddress = email,
                Password = hashedPassword,
                RoleID = RoleId,
                UpdatedBy = updatedBy
            };

            await _unitOfWork.Context.AddAsync(user);
            await _unitOfWork.CommitAsync();

            return user;
        }
    }
}
