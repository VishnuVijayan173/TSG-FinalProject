﻿using BugProject.Application.Common.Interfaces;
using BugProject.Domain.Entities;
using BugProject.Domain.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BugProject.Infrastructure.Persistence.Repository
{
    public class User_RoleRepository : Repository<User_Role>, IUser_RoleRepository
    {
        private readonly IUnitOfWork _unitOfWork;
        public User_RoleRepository(IUnitOfWork unitOfWork) : base(unitOfWork)
        {
            this._unitOfWork = unitOfWork;
        }
    }
}
