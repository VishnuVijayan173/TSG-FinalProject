﻿using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Linq;
using System.Runtime.InteropServices;
using System.Threading.Tasks;
using System.Transactions;
using BugProject.Application.Common.Interfaces;
using BugProject.Domain.Repositories;
using BugProject.Infrastructure.Persistence.Data;
using Microsoft.EntityFrameworkCore;

namespace BugProject.Infrastructure.Persistence.Repository
{
    public class Repository<TEntity> : IRepository<TEntity> where TEntity : class
    { 
        private readonly IUnitOfWork unitOfWork;

        public Repository(IUnitOfWork unitOfWork)
        {
            this.unitOfWork = unitOfWork;
        }

        public async Task<TEntity> AddAsync(TEntity entity)
        {
            try
            {
                await unitOfWork.Context.Set<TEntity>().AddAsync(entity);
                await unitOfWork.CommitAsync();
                return entity;
            }
            catch (Exception ex)
            {
                Transaction.Current.Rollback();
                Console.WriteLine(ex.Message);
                return null;
            }
        }

        public async Task<TEntity> DeleteAsync(Guid id)
        {
            try
            {
                var entity = await unitOfWork.Context.Set<TEntity>().FindAsync(id); if (entity == null)
                {
                    return null;
                }
                unitOfWork.Context.Set<TEntity>().Remove(entity);
                await unitOfWork.CommitAsync();
                return entity;
            }
            catch (Exception ex)
            {
                Transaction.Current.Rollback();
                Console.WriteLine(ex.Message);
                return null;
            }
        }

        public async Task<IEnumerable<TEntity>> GetAllAsync()
            {
                try
                {
                    return await unitOfWork.Context.Set<TEntity>().ToListAsync();
                }
                catch (Exception ex)
                {
                    Transaction.Current.Rollback();
                    Console.WriteLine(ex.Message);
                    return null;
                }
            }
         

        public async Task<TEntity> GetAsync(Guid id)
        {
            try
            {
                return await unitOfWork.Context.Set<TEntity>().FindAsync(id);
            }
            catch (Exception ex)
            {
                Transaction.Current.Rollback();
                Console.WriteLine(ex.Message);
                return null;
            }
        }

        public async Task<TEntity> UpdateAsync(Guid id, TEntity entity)
            {
                try
                {
                    var updatedEntity = await unitOfWork.Context.Set<TEntity>().FindAsync(id);
                    if (updatedEntity == null)
                    {
                        return null;
                    }
                    unitOfWork.Context.Set<TEntity>().Update(entity);
                    await unitOfWork.CommitAsync();
                    return entity;
                }
                catch (Exception ex)
                {
                    Transaction.Current.Rollback();
                    Console.WriteLine(ex.Message);
                    return null;
                }
            }
    }
    }