﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BugProject.Infrastructure.Persistence.DTO
{
    public class AddBugRequest
    {
        public Guid BugID { get; set; }
        public string BugName { get; set; }
        public string BugDescription { get; set; }
        public Guid StatusID { get; set; }
        public Guid AllocationID { get; set; }
        public DateTime CreatedOn { get; set; }
        public Guid RaisedBy { get; set; }
        public Guid AssignedTo { get; set; }
        public Guid UpdatedBy { get; set; }
        public DateTime UpdatedOn { get; set; }
    }
}
