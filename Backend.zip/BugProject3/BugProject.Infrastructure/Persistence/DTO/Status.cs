﻿namespace BugProject.Infrastructure.Persistence.DTO
{
    public class Status
    {
        public Guid StatusID { get; set; }
        public string BugStatus { get; set; }
        public DateTime UpdatedOn { get; set; }

        public Guid UpdatedBy { get; set; }
    }
}
