﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BugProject.Infrastructure.Persistence.DTO
{
    public class UpdateProjectAllocationRequest
    {
        public Guid AllocationID { get; set; }

        public Guid ProjectID { get; set; }

        public Guid UserID { get; set; }
        public DateTime UpdatedOn { get; set; }

        public Guid UpdatedBy { get; set; }
    }
}
