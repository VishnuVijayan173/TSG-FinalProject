﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BugProject.Infrastructure.Persistence.DTO
{
    public class AddUser_RoleRequest
    {
        public Guid UserID { get; set; }

        public Guid RoleID { get; set; }
    }
}
