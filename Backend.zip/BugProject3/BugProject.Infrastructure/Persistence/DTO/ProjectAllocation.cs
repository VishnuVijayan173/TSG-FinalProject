﻿namespace BugProject.Infrastructure.Persistence.DTO
{
    public class ProjectAllocation
    {
        public Guid AllocationID { get; set; }

        public Guid ProjectID { get; set; }

        public Guid UserID { get; set; }
        public DateTime UpdatedOn { get; set; }

        public Guid UpdatedBy { get; set; }
    }
}
