﻿using AutoMapper;
using BugProject.Application.Common.Interfaces;
using BugProject.Application.Common.Logger;
using Microsoft.AspNetCore.Mvc;

namespace BugProject.Api.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class ProjectAllocationController : Controller
    {
        private readonly IProjectAllocationService projectAllocationService;
        private readonly IMapper mapper;
        private readonly ILoggerManager _logger;

        public ProjectAllocationController(IProjectAllocationService projectAllocationService, IMapper mapper,ILoggerManager logger)
        {
            this.projectAllocationService = projectAllocationService;
            this.mapper = mapper;
            this._logger = logger;
        }
        [HttpGet]

        public async Task<IActionResult> GetAllProjectAllocationsAsync()
        {
            try
            {
                var projectAllocations = await projectAllocationService.GetAllAsync();


                var projectAllocationsDTO = new List<Infrastructure.Persistence.DTO.ProjectAllocation>();
                projectAllocations.ToList().ForEach(projectAllocation =>
                {
                    var projectAllocationDTO = new Infrastructure.Persistence.DTO.ProjectAllocation()
                    {
                        AllocationID = projectAllocation.AllocationID,
                        ProjectID = (Guid)projectAllocation.ProjectID,
                        UserID = (Guid)projectAllocation.UserID,
                        UpdatedOn = projectAllocation.UpdatedOn,
                        UpdatedBy = (Guid)projectAllocation.UpdatedBy,

                    };
                    projectAllocationsDTO.Add(projectAllocationDTO);
                });


                return Ok(projectAllocationsDTO);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Something went wrong: {ex}");
                return StatusCode(500, "Internal server error");
            }
        }
        [HttpGet]
        [Route("{id:guid}")]
        [ActionName("GetProjectAllocationAsync")]
        public async Task<IActionResult> GetProjectAllocationAsync(Guid id)
        {
            try
            {
                var projectAllocation = await projectAllocationService.GetAsync(id);

                if (projectAllocation == null)
                {
                    return NotFound();
                }

                var projectAllocations = await projectAllocationService.GetAllAsync();
                var projectAllocationsDTO = new List<Infrastructure.Persistence.DTO.ProjectAllocation>();
                projectAllocations.ToList().ForEach(projectAllocation =>
                {
                    if (projectAllocation.AllocationID == id)
                    {
                        var projectAllocationDTO = new Infrastructure.Persistence.DTO.ProjectAllocation()
                        {
                            AllocationID = projectAllocation.AllocationID,
                            ProjectID = (Guid)projectAllocation.ProjectID,
                            UserID = (Guid)projectAllocation.UserID,
                            UpdatedOn = projectAllocation.UpdatedOn,
                            UpdatedBy = (Guid)projectAllocation.UpdatedBy,

                        };
                        projectAllocationsDTO.Add(projectAllocationDTO);
                    }
                });
                return Ok(projectAllocationsDTO);
            }
            catch(Exception ex)
            {
                _logger.LogError($"Something went wrong: {ex}");
                return StatusCode(500, "Internal server error");
            }
        }

        [HttpPost]

        public async Task<IActionResult> AddProjectAllocationAsync(Infrastructure.Persistence.DTO.AddProjectAllocationRequest addProjectAllocationRequest)
        {
            try
            {
                var projectAllocation = new Domain.Entities.ProjectAllocation()
                {
                    ProjectID = addProjectAllocationRequest.ProjectID,
                    UserID = addProjectAllocationRequest.UserID,
                    UpdatedOn = addProjectAllocationRequest.UpdatedOn,
                    UpdatedBy = addProjectAllocationRequest.UpdatedBy,
                };

                // Pass details to Service
                projectAllocation = await projectAllocationService.AddAsync(projectAllocation);

                // Convert back to DTO

                var projectAllocationDTO = new Infrastructure.Persistence.DTO.ProjectAllocation
                {
                    AllocationID = projectAllocation.AllocationID,
                    ProjectID = (Guid)projectAllocation.ProjectID,
                    UserID = (Guid)projectAllocation.UserID,
                    UpdatedOn = projectAllocation.UpdatedOn,
                    UpdatedBy = (Guid)projectAllocation.UpdatedBy,
                };

                return CreatedAtAction(nameof(GetProjectAllocationAsync), new { id = projectAllocationDTO.AllocationID }, projectAllocationDTO);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Something went wrong: {ex}");
                return StatusCode(500, "Internal server error");
            }
            
        }
        [HttpDelete]
        [Route("{id:guid}")]

        public async Task<IActionResult> DeleteProjectAllocationAsync(Guid id)
        {
            try
            {
                // Get projectAllocation from database
                var projectAllocation = await projectAllocationService.DeleteAsync(id);

                // If null NotFound
                if (projectAllocation == null)
                {
                    return NotFound();
                }

                // Convert response back to DTO
                var projectAllocationDTO = new Infrastructure.Persistence.DTO.ProjectAllocation
                {
                    AllocationID = projectAllocation.AllocationID,
                    ProjectID = (Guid)projectAllocation.ProjectID,
                    UserID = (Guid)projectAllocation.UserID,
                    UpdatedOn = projectAllocation.UpdatedOn,
                    UpdatedBy = (Guid)projectAllocation.UpdatedBy,
                };


                // return Ok response
                return Ok(projectAllocationDTO);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Something went wrong: {ex}");
                return StatusCode(500, "Internal server error");
            }
        }
        [HttpPut]
        [Route("{id:guid}")]
        public async Task<IActionResult> UpdateProjectAllocationAsync([FromRoute] Guid id,
            [FromBody] Infrastructure.Persistence.DTO.UpdateProjectAllocationRequest updateProjectAllocationRequest)
        {

            try
            {
                var projectAllocation = new Domain.Entities.ProjectAllocation()
                {
                    ProjectID = updateProjectAllocationRequest.ProjectID,
                    UserID = updateProjectAllocationRequest.UserID,

                };


                // Update Region using Service
                projectAllocation = await projectAllocationService.UpdateAsync(id, projectAllocation);


                // If Null then NotFound
                if (projectAllocation == null)
                {
                    return NotFound();
                }

                // Convert Domain back to DTO
                var projectAllocationDTO = new Infrastructure.Persistence.DTO.ProjectAllocation
                {
                    AllocationID = projectAllocation.AllocationID,
                    ProjectID = (Guid)projectAllocation.ProjectID,
                    UserID = (Guid)projectAllocation.UserID,
                    UpdatedOn = projectAllocation.UpdatedOn,
                    UpdatedBy = (Guid)projectAllocation.UpdatedBy,
                };


                // Return Ok response
                return Ok(projectAllocationDTO);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Something went wrong: {ex}");
                return StatusCode(500, "Internal server error");
            }
        }


    }
}
