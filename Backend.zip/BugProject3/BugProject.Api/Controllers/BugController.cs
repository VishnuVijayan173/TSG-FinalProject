﻿using Microsoft.AspNetCore.Mvc;
using BugProject.Domain.Repositories;
using AutoMapper;
using Microsoft.AspNetCore.Authorization;
using System.Data;
using BugProject.Infrastructure.Persistence.DTO;
using BugProject.Domain.Entities;
using BugProject.Application.Common.Logger;
using BugProject.Application.Common.Interfaces;
using BugProject.Application.Services;

namespace BugProject.Api.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class BugController : Controller
    {
        private readonly IBugService bugService;
        private readonly IMapper mapper;
        private readonly ILoggerManager _logger;
        private readonly IStatusService statusService;
        private readonly IProjectAllocationService projectAllocationService;
        private readonly IProjectService projectService;
      

        public BugController(IBugService bugService, IMapper mapper, ILoggerManager logger,
            IStatusService statusService, IProjectAllocationService projectAllocationService, IProjectService projectService)
        {
            this.bugService = bugService;
            this.mapper = mapper;
            this._logger = logger;
            this.statusService = statusService;
            this.projectAllocationService = projectAllocationService;
            this.projectService = projectService;
        }
        [HttpGet]
       
        public async Task<IActionResult> GetAllBugsAsync()
        {
            try
            {
                var bugs = await bugService.GetAllAsync();
                var bugsDTO = new List<Infrastructure.Persistence.DTO.Bug>();
                bugs.ToList().ForEach(async bug =>
                {
                    var bugDTO = new Infrastructure.Persistence.DTO.Bug()
                    {
                        BugID = bug.BugID,
                        BugName = bug.BugName,
                        BugDescription = bug.BugDescription,
                        StatusID = (Guid)bug.StatusID,
                        RaisedBy = (Guid)bug.RaisedBy,
                        AllocationID= (Guid)bug.AllocationID,
                        CreatedOn = bug.CreatedOn,
                        UpdatedOn = bug.UpdatedOn,

                    };
                    

                    bugsDTO.Add(bugDTO);
                    _logger.LogInfo($"{bugsDTO.Count} record for Bug got Retrieved ");
                });
                return Ok(bugsDTO);
            }


            catch (Exception ex)
            {
                _logger.LogError($"Something went wrong: {ex}");
                return StatusCode(500, "Internal server error");
            }
        }
        [HttpGet]
        [Route("{id:guid}")]
        [ActionName("GetBugAsync")]
        public async Task<IActionResult> GetBugAsync(Guid id)
        {
            try
            {
                var bug = await bugService.GetAsync(id);

                if (bug == null)
                {
                    _logger.LogInfo("The recod was not found ");
                    return NotFound();
                }

                var bugs = await bugService.GetAllAsync();
                var bugsDTO = new List<Infrastructure.Persistence.DTO.Bug>();
                bugs.ToList().ForEach(bug =>
                {
                    if (bug.BugID == id)
                    {
                        var bugDTO = new Infrastructure.Persistence.DTO.Bug()
                        {
                            BugID = bug.BugID,
                            BugName = bug.BugName,
                            BugDescription = bug.BugDescription,
                            StatusID = (Guid)bug.StatusID,
                            RaisedBy = (Guid)bug.RaisedBy,
                            CreatedOn = bug.CreatedOn,
                            UpdatedOn = bug.UpdatedOn,

                        };
                        bugsDTO.Add(bugDTO);
                        _logger.LogInfo("Bug Retrieved with id ");
                    }
                });
                
                return Ok(bugsDTO);
            }
            catch(Exception ex)
            {
                _logger.LogError(ex.Message);
                return BadRequest(ex.Message);
            }
        }

        [HttpPost]
        
        public async Task<IActionResult> AddBugAsync(Infrastructure.Persistence.DTO.AddBugRequest addBugRequest)
        {
            try
            {
                
                
                var bug = new Domain.Entities.Bug()
                {
                    BugName = addBugRequest.BugName,
                    BugDescription = addBugRequest.BugDescription,
                    StatusID = addBugRequest.StatusID,
                    AllocationID= addBugRequest.AllocationID,
                    CreatedOn = addBugRequest.CreatedOn,
                    RaisedBy= addBugRequest.RaisedBy,
                    AssignedTo= addBugRequest.AssignedTo,
                    UpdatedBy= addBugRequest.UpdatedBy,
                    UpdatedOn = addBugRequest.UpdatedOn,
                };
                bug = await bugService.AddAsync(bug);

                
                _logger.LogInfo("Bug Added ");
                
                return Ok(CreatedAtAction(nameof(GetBugAsync), new { id = bug.BugID }, bug));
            }
            catch(Exception ex)
            {
                
                _logger.LogError(ex.Message);
                return BadRequest(ex.Message);
            }
            
        }
        [HttpDelete]
        [Route("{id:guid}")]
        
        public async Task<IActionResult> DeleteBugAsync(Guid id)
        {
            try
            {
                var bug = await bugService.DeleteAsync(id);

                if (bug == null)
                {
                    return NotFound();
                }

                _logger.LogInfo("Bug Deleted ");
                return Ok(bug);
            }
            catch(Exception ex)
            {
                _logger.LogError(ex.Message);
                return BadRequest(ex.Message);
            }
        }
        [HttpPut]
        [Route("{id:guid}")]
        public async Task<IActionResult> UpdateBugAsync([FromRoute] Guid id,
            [FromBody] Infrastructure.Persistence.DTO.UpdateBugRequest updateBugRequest)
        {

            try
            {
                var bug = new Domain.Entities.Bug()
                {
                    BugName = updateBugRequest.BugName,
                    BugDescription = updateBugRequest.BugDescription,

                };

                bug = await bugService.UpdateAsync(id, bug);
                if (bug == null)
                {
                    return NotFound();
                }
                //var bugDTO = new Infrastructure.Persistence.DTO.Bug
                //{

                //    BugName = bug.BugName,
                //    BugDescription = bug.BugDescription,
                //    CreatedOn = bug.CreatedOn,
                //    UpdatedOn = bug.UpdatedOn,
                //};

                _logger.LogInfo("Bug Updated ");
              
                return Ok(bug);
            }
            catch(Exception ex)
            {
                _logger.LogError(ex.Message);
                return BadRequest(ex.Message);
            }
        }


    }
 }
