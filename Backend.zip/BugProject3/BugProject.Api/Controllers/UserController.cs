﻿using AutoMapper;
using BugProject.Application.Common.Interfaces;
using BugProject.Application.Common.Logger;
using BugProject.Domain.Entities;
using BugProject.Domain.Repositories;
using BugProject.Infrastructure.Persistence.DTO;
using BugProject.Infrastructure.Persistence.Repository;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;

namespace BugProject.Api.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class UserController : Controller
    {
        private readonly IUserService userService;
        private readonly IMapper mapper;
        private readonly ITokenHandlerRepository _tokenHandler;
        private readonly ILoggerManager _logger;

        public UserController(IUserService userService, IMapper mapper, ITokenHandlerRepository tokenHandler, ILoggerManager logger)
        {
            this.userService = userService;
            this.mapper = mapper;
            this._tokenHandler = tokenHandler;
            this._logger = logger;
        }
        [HttpGet]
        [ActionName("GetAllUserAsync")]
        public async Task<IActionResult> GetAllUsersAsync()
        {
            try
            {
                var users = await userService.GetAllAsync();


                var usersDTO = new List<Infrastructure.Persistence.DTO.User>();
                users.ToList().ForEach(user =>
                {
                    var userDTO = new Infrastructure.Persistence.DTO.User()
                    {
                        UserID = user.UserID,
                        UserName = user.UserName,
                        EmailAddress = user.EmailAddress,
                        RoleID = user.RoleID,
                        UpdatedBy = (Guid)user.UpdatedBy,
                        UpdatedOn = user.UpdatedOn,

                    };
                    usersDTO.Add(userDTO);
                });


                return Ok(usersDTO);
            }
            catch(Exception ex)
            {
                _logger.LogError($"Something went wrong: {ex}");
                return StatusCode(500, "Internal server error");
            }
        }
        [HttpGet]
        [Route("{id:guid}")]
        [ActionName("GetUserAsync")]
        public async Task<IActionResult> GetUserAsync(Guid id)
        {
            try
            {
                var user = await userService.GetAsync(id);

                if (user == null)
                {
                    return NotFound();
                }

                var users = await userService.GetAllAsync();
                var usersDTO = new List<Infrastructure.Persistence.DTO.User>();
                users.ToList().ForEach(user =>
                {
                    if (user.UserID == id)
                    {
                        var userDTO = new Infrastructure.Persistence.DTO.User()
                        {
                            UserID = user.UserID,
                            UserName = user.UserName,
                            Password = user.Password,
                            UpdatedBy = (Guid)user.UpdatedBy,
                            UpdatedOn = user.UpdatedOn,

                        };
                        usersDTO.Add(userDTO);
                    }
                });
                return Ok(usersDTO);
            }
            catch(Exception ex)
            {
                _logger.LogError($"Something went wrong: {ex}");
                return StatusCode(500, "Internal server error");
            }
        }

        
        [HttpDelete]
        [Route("{id:guid}")]

        public async Task<IActionResult> DeleteUserAsync(Guid id)
        {
            try
            {
                // Get user from database
                var user = await userService.DeleteAsync(id);

                // If null NotFound
                if (user == null)
                {
                    return NotFound();
                }

                // Convert response back to DTO
                var userDTO = new Infrastructure.Persistence.DTO.User
                {
                    UserID = user.UserID,
                    UserName = user.UserName,
                    UpdatedBy = (Guid)user.UpdatedBy,

                    UpdatedOn = user.UpdatedOn,
                };


                // return Ok response
                return Ok(userDTO);
            }
            catch(Exception ex)
            {
                _logger.LogError($"Something went wrong: {ex}");
                return StatusCode(500, "Internal server error");
            }
        }
        [HttpPut]
        [Route("{id:guid}")]
        public async Task<IActionResult> UpdateUserAsync([FromRoute] Guid id,
            [FromBody] Infrastructure.Persistence.DTO.UpdateUserRequest updateUserRequest)
        {

            try
            {
                var user = new Domain.Entities.User()
                {
                    UserName = updateUserRequest.UserName,
                    Password = updateUserRequest.Password,
                    UpdatedBy = updateUserRequest.UpdatedBy,
                    UpdatedOn = updateUserRequest.UpdatedOn,

                };


                // Update Region using Service
                user = await userService.UpdateAsync(id, user);


                // If Null then NotFound
                if (user == null)
                {
                    return NotFound();
                }

                // Convert Domain back to DTO
                var userDTO = new Infrastructure.Persistence.DTO.User
                {
                    UserID = user.UserID,
                    UserName = user.UserName,
                    Password = user.Password,
                    UpdatedBy = (Guid)user.UpdatedBy,
                    UpdatedOn = user.UpdatedOn,
                };


                // Return Ok response
                return Ok(userDTO);
            }
            catch(Exception ex)
            {
                _logger.LogError($"Something went wrong: {ex}");
                return StatusCode(500, "Internal server error");
            }
        }

        [HttpPost]
        [Route("login")]
        public async Task<IActionResult> Authenticate([FromBody] LoginRequest userObj)
        {
            try
            {
                var user = await userService.AuthenticateAsync(userObj.UserName, userObj.Password);

                if (user == null)
                {
                    return BadRequest(new { message = "Username or password is incorrect" });
                }

                // Generate a JWT token and return it to the client
                var token = _tokenHandler.CreateTokenAsync(user);
                return Ok(token);
            }
            catch(Exception ex)
            {
                _logger.LogError($"Something went wrong: {ex}");
                return StatusCode(500, "Internal server error");
            }
            
        }
        [HttpPost("register")]
        public async Task<IActionResult> Register([FromBody] RegisterRequest userObj)
        {
            try
            {
                var userExists = await userService.FindByNameAsync(userObj.UserName);
                if (userExists != null)
                    return StatusCode(StatusCodes.Status500InternalServerError, new { Message = "User already exists!" });

                var result = await userService.RegisterAsync(userObj.UserName, userObj.EmailAddress, userObj.Password, userObj.RoleID, userObj.UpdatedBy);
                var user = await userService.AuthenticateAsync(userObj.UserName, userObj.Password);

                if (result == null)
                    return StatusCode(StatusCodes.Status500InternalServerError, new { Message = "User creation failed! Please check user details and try again." });

                return Ok(new
                {
                    UserID = user.UserID,
                    UserName = user.UserName,
                    EmailAddress = user.EmailAddress,
                    Password = userObj.Password,
                    UpdatedBy = userObj.UpdatedBy,
                    Message = "User created successfully!"
                });
            }
            catch(Exception ex)
            {
                _logger.LogError($"Something went wrong: {ex}");
                return StatusCode(500, "Internal server error");
            }
        }


    }
}
