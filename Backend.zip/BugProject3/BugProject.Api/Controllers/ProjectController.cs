﻿using AutoMapper;
using BugProject.Application.Common.Interfaces;
using BugProject.Application.Common.Logger;
using Microsoft.AspNetCore.Mvc;

namespace BugProject.Api.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class ProjectController : Controller
    {
        private readonly IProjectService projectService;
        private readonly IMapper mapper;
        private readonly ILoggerManager _logger;

        public ProjectController(IProjectService projectService, IMapper mapper,ILoggerManager logger)
        {
            this.projectService = projectService;
            this.mapper = mapper;
            this._logger = logger;
        }
        [HttpGet]

        public async Task<IActionResult> GetAllProjectsAsync()
        {
            try
            {
                var projects = await projectService.GetAllAsync();
                if (projects == null)
                {
                    return NoContent();
                }

                var projectsDTO = new List<Infrastructure.Persistence.DTO.Project>();
                projects.ToList().ForEach(project =>
                {
                    var projectDTO = new Infrastructure.Persistence.DTO.Project()
                    {
                        ProjectID = project.ProjectID,
                        ProjectName = project.ProjectName,
                        ProjectDetails = project.ProjectDetails,
                        UpdatedOn = project.UpdatedOn,
                        UpdatedBy = (Guid)project.UpdatedBy,

                    };
                    projectsDTO.Add(projectDTO);
                });


                return Ok(projectsDTO);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Something went wrong: {ex}");
                return StatusCode(500, "Internal server error");
            }
        }
        [HttpGet]
        [Route("{id:guid}")]
        [ActionName("GetProjectAsync")]
        public async Task<IActionResult> GetProjectAsync(Guid id)
        {
            try
            {
                var project = await projectService.GetAsync(id);

                if (project == null)
                {
                    return NotFound();
                }

                var projects = await projectService.GetAllAsync();
                var projectsDTO = new List<Infrastructure.Persistence.DTO.Project>();
                projects.ToList().ForEach(project =>
                {
                    if (project.ProjectID == id)
                    {
                        var projectDTO = new Infrastructure.Persistence.DTO.Project()
                        {
                            ProjectID = project.ProjectID,
                            ProjectName = project.ProjectName,
                            ProjectDetails = project.ProjectDetails,
                            UpdatedOn = project.UpdatedOn,
                            UpdatedBy = (Guid)project.UpdatedBy,

                        };
                        projectsDTO.Add(projectDTO);
                    }
                });
                return Ok(projectsDTO);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Something went wrong: {ex}");
                return StatusCode(500, "Internal server error");
            }
        }

        [HttpPost]

        public async Task<IActionResult> AddProjectAsync(Infrastructure.Persistence.DTO.AddProjectRequest addProjectRequest)
        {

            try
            {
                var project = new Domain.Entities.Project()
                {
                    ProjectName = addProjectRequest.ProjectName,
                    ProjectDetails = addProjectRequest.ProjectDetails,
                    UpdatedOn = addProjectRequest.UpdatedOn,
                    UpdatedBy = addProjectRequest.UpdatedBy,
                };

                project = await projectService.AddAsync(project);


                var projectDTO = new Infrastructure.Persistence.DTO.Project
                {
                    ProjectID = project.ProjectID,
                    ProjectName = project.ProjectName,
                    ProjectDetails = project.ProjectDetails,
                    UpdatedOn = project.UpdatedOn,
                    UpdatedBy = (Guid)project.UpdatedBy,
                };

                return CreatedAtAction(nameof(GetProjectAsync), new { id = projectDTO.ProjectID }, projectDTO);
            }
            catch(Exception ex)
            {
                _logger.LogError($"Something went wrong: {ex}");
                return StatusCode(500, "Internal server error");
            }
        }
        [HttpDelete]
        [Route("{id:guid}")]

        public async Task<IActionResult> DeleteProjectAsync(Guid id)
        {
   
            try
            {
                var project = await projectService.DeleteAsync(id);

                if (project == null)
                {
                    return NotFound();
                }

                var projectDTO = new Infrastructure.Persistence.DTO.Project
                {
                    ProjectID = project.ProjectID,
                    ProjectName = project.ProjectName,
                    ProjectDetails = project.ProjectDetails,
                    UpdatedOn = project.UpdatedOn,
                    UpdatedBy = (Guid)project.UpdatedBy,
                };


                return Ok(projectDTO);
            }
            catch(Exception ex)
            {
                _logger.LogError($"Something went wrong: {ex}");
                return StatusCode(500, "Internal server error");
            }
        }
        [HttpPut]
        [Route("{id:guid}")]
        public async Task<IActionResult> UpdateProjectAsync([FromRoute] Guid id,
            [FromBody] Infrastructure.Persistence.DTO.UpdateProjectRequest updateProjectRequest)
        {

            try
            {
                var project = new Domain.Entities.Project()
                {
                    ProjectName = updateProjectRequest.ProjectName,
                    ProjectDetails = updateProjectRequest.ProjectDetails,
                    UpdatedOn = updateProjectRequest.UpdatedOn,
                    UpdatedBy = updateProjectRequest.UpdatedBy,

                };

                project = await projectService.UpdateAsync(id, project);


                if (project == null)
                {
                    return NotFound();
                }

                var projectDTO = new Infrastructure.Persistence.DTO.Project
                {
                    ProjectID = project.ProjectID,
                    ProjectName = project.ProjectName,
                    ProjectDetails = project.ProjectDetails,
                    UpdatedOn = project.UpdatedOn,
                    UpdatedBy = (Guid)project.UpdatedBy,
                };


                return Ok(projectDTO);
            }
            catch(Exception ex)
            {
                _logger.LogError($"Something went wrong: {ex}");
                return StatusCode(500, "Internal server error");
            }
        }


    }
}
