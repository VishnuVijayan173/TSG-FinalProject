﻿
using System.ComponentModel.DataAnnotations.Schema;

namespace BugProject.Domain.Entities
{
    public class Bug
    {
        public Guid BugID { get; set; }
        public string BugName { get; set; }
        public string BugDescription { get; set; }
        [ForeignKey("Status")]
        public Nullable<Guid> StatusID { get; set; }
        [ForeignKey("ProjectAllocation")]
        public Nullable<Guid> AllocationID { get; set; }
        public DateTime CreatedOn { get; set; }
        [ForeignKey("User")]
        public Nullable<Guid> RaisedBy { get; set; }
        [ForeignKey("User")]
        public Nullable<Guid> AssignedTo { get; set; }
        [ForeignKey("User")]
        public Nullable<Guid> UpdatedBy { get; set; }
      
        public DateTime UpdatedOn { get; set; }
       
        public virtual Status status { get; set; }
  
        public virtual User user { get; set; }
 
        public virtual ProjectAllocation projectAllocation { get; set; }
    }
}
