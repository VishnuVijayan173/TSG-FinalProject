﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BugProject.Domain.Entities
{
    public class ProjectAllocation
    {
        [Key]
        public Guid AllocationID { get; set; }

        public Nullable<Guid> ProjectID { get; set; }
        [ForeignKey("User")]
        public Nullable<Guid> UserID { get; set; }
        public DateTime UpdatedOn { get; set; }
        [ForeignKey("User")]
        public Guid UpdatedBy { get; set; }
        [ForeignKey("ProjectID")]
        public virtual Project project { get;set; }
        public virtual User user { get; set; }

        public IEnumerable<Bug> Bug { get; set; }
    }
}
