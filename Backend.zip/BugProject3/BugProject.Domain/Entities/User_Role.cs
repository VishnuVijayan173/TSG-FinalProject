﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace BugProject.Domain.Entities
{
    public class User_Role
    {
        [Key]
        public Guid Id { get; set; }

        public Guid UserID { get; set; }
        [JsonIgnore]
        [ForeignKey("UserID")]
        public virtual User User { get; set; }

        public Guid RoleID { get; set; }
        [JsonIgnore]
        [ForeignKey("RoleID")]
        public virtual Role Role { get; set; }
    }
}
