﻿namespace BugProject.Domain;
public class Class1
{

}
