﻿using BugProject.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BugProject.Domain.Repositories
{
    public interface IUserRepository : IRepository<User>
    {
        Task<User> AuthenticateAsync(string username, string password);
        Task<User> RegisterAsync(string username, string email, string password, Guid RoleId, Guid updatedBy);
        Task<User> AddAsync(User user);
        Task<User> FindByNameAsync(string username);
    }
}
